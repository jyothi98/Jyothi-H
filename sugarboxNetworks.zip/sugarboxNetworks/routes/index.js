var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken');
var mysql = require('mysql');
var validator = require("email-validator");
const fs = require("fs");
var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'sugarboxnetworks'
});
connection.connect();
const key = fs.readFileSync('./secrete_key.json', 
{encoding:'utf8', flag:'r'});

function generateAccessToken(username) {
  // expires after half and hour (1800 seconds = 30 minutes)  JSON.parse(key).Private_key
  return jwt.sign(username, JSON.parse(key).secreteKey, { expiresIn:  "1800s"});
}

function authenticateToken(req, res, next) {
  // Gather the jwt access token from the request header
  if(req.headers['authorization']){
  const authHeader = req.headers['authorization'];
  const token = authHeader; 
  if (token == null) return res.sendStatus(401) // if there isn't any token
  jwt.verify(token,  JSON.parse(key).secreteKey,(err, user) => {
    if (err) return res.sendStatus(403);
    req.query.email = user.email;
    next() // pass the execution off to whatever request the client intended
  });
}else{
  res.status(400).json({"error": "request header authorization is required"})
}
}

router.post('/creteUser', (req, res) => {
  let email = validator.validate(req.body.email);
  let password = Buffer.from(req.body.password).toString('base64');
  if (email) {
    connection.query(`select * from users where email="${req.body.email}"`, function (error, data) {
      if (error) {
        res.status(400).send(error)
      } else if (data.length == 0) {
        connection.query(`Insert into users set email="${req.body.email}" , password="${password}"`, function (error1, results, fields) {
          if (error1) throw error;
          console.log(results)
          const token = generateAccessToken({ email: req.body.email});
          res.status(200).json({
            "message": "User created successfully",
            "accessToken": token
          });
        });
      }else{
        res.status(400).json({
         "error" : `${req.body.email} already exists.`
        });
      }
    });
  }
  else {
    res.status(400).json({ "error": "Please enter a valid email-id" });
  }
});

router.delete('/deleteUser', authenticateToken, (req, res) => {

    let email = req.query.email;
  connection.query(`delete from users where email="${email}"`, function (error1, results, fields) {
    if (error1) throw error1;
    if(results.affectedRows > 0){
      res.status(200).json({
        "message": "User deleted successfully"
      });
    }else{
      res.status(400).json({
        "error": "User doesn't exists"
      });
    }
   
  });
});



/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

module.exports = router;
